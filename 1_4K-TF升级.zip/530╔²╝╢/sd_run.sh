#!/bin/sh

echo "start"

/home/aoen
regs 1006809c 9f


if [ -e /home/mac ];then
    a=`ifconfig eth0|grep eth0|awk '{print $5}'`
    b=`cat /home/mac|sed 'y/abcdef/ABCDEF/'`

    if [ "$a" = "$b" ];then
    	if [ -e /home/upgraded ];then
    		c=`cat /home/upgraded`
    	else
    		c=""
    	fi

    	if [ "$b" != "$c" ];then
        	echo "upgrade successfully!"
        	/home/i2s_play /home/shengjichenggong.pcm
        	echo $b > /home/upgraded
        fi

        exit 0
    fi
fi

touch /mnt/mtd/factorytest_flag
a=`ifconfig eth0|grep eth0|awk '{print $5}'`
echo -n "$a" > /home/mac

if [ -e /home/sd_upgrade.bin ]
then
    /home/i2s_play /home/kaishishengjizhukong.pcm
    cp /home/upgrader /var/upgrader
    /var/upgrader file /home/sd_upgrade.bin
	/home/i2s_play /home/zhukongshengjichenggong.pcm
while true
do
	sleep 1
	/home/i2s_play /home/zhukongshengjichenggong.pcm
done
fi
if [ -e /home/ota.bin ]
then
	/home/i2s_play /home/kaishishengjidanpianji.pcm
	/home/upg /home/ota.bin
    if [ $? -eq 0 ]
    then
        /home/i2s_play /home/danpianjishengjichenggong.pcm
    else
        echo ++$?++
        /home/i2s_play /home/danpianjishengjishibai.pcm
    fi
fi


exit 0
